# Western Excellent Editor
We're going to put all the skills we learned in this class together in a final project. 
We're going to build our very own text editor, called Wee, short for the Western Excellent Editor. 
This text editor will give you the ability to efficiently edit text in a terminal window, 
and with some work, may even become your personal favorite. 
You should get to a point where Wee is working enough that you can continue developing Wee using Wee! 
How's that for recursion?

The project writeup is available [here](https://docs.google.com/document/d/1k6GFOYSCLteJvejpsdNFI1JaIKLd92TM3L2t039Mnbg/edit?usp=sharing).
