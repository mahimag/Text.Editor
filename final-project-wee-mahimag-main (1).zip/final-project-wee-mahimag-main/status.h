#ifndef STATUS_H
#define STATUS_H

void status_message(int x, int y, const char* s);

#endif // STATUS_H
