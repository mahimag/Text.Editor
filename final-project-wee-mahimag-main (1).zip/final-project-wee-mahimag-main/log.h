#ifndef LOG_H
#define LOG_H

#include <stdarg.h>

void log_debug(const char* message, ...);

#endif
